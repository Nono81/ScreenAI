if (typeof globalThis.browser !== "undefined" && typeof globalThis.chrome === "undefined") {
  globalThis.chrome = globalThis.browser;
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "capture-fullscreen" || command === "capture-region") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const dataUrl = await chrome.tabs.captureVisibleTab({
      format: "png",
      quality: 95
    });
    chrome.tabs.sendMessage(tab.id, {
      type: "SCREENAI_CAPTURE",
      mode: command === "capture-fullscreen" ? "fullscreen" : "region",
      dataUrl
    });
  }
  if (command === "toggle-highlight") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { action: "toggle-highlight" });
    }
  }
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SCREENAI_CAPTURE_TAB") {
    chrome.tabs.captureVisibleTab({ format: "png", quality: 95 }).then((dataUrl) => sendResponse({ dataUrl })).catch((err) => sendResponse({ error: err.message }));
    return true;
  }
});
