if (typeof globalThis.browser !== "undefined" && typeof globalThis.chrome === "undefined") {
  globalThis.chrome = globalThis.browser;
}
const DEFAULT_MODELS = {
  claude: "claude-sonnet-4-20250514",
  openai: "gpt-4o",
  gemini: "gemini-2.0-flash",
  mistral: "mistral-large-latest",
  grok: "grok-2-vision-1220",
  ollama: "llava"
};
const PROVIDER_LABELS = {
  claude: "Claude (Anthropic)",
  openai: "GPT (OpenAI)",
  gemini: "Gemini (Google)",
  mistral: "Mistral",
  grok: "Grok (xAI)",
  ollama: "Ollama (Local)"
};
const LANGUAGE_PROMPTS = {
  auto: "Respond in the user's language.",
  fr: "Réponds toujours en français.",
  en: "Always respond in English.",
  es: "Responde siempre en español.",
  de: "Antworte immer auf Deutsch."
};
const DEFAULT_SYSTEM_PROMPT = "You are a visual assistant. The user shares annotated screenshots to get help. Analyze the image and annotations (arrows, highlights, rectangles) to understand precisely what the user is showing you. Respond clearly and actionably.";
const DEFAULT_SETTINGS = {
  defaultProvider: "claude",
  providers: {
    claude: { type: "claude", label: "Claude", apiKey: "", model: DEFAULT_MODELS.claude, enabled: false },
    openai: { type: "openai", label: "OpenAI", apiKey: "", model: DEFAULT_MODELS.openai, enabled: false },
    gemini: { type: "gemini", label: "Gemini", apiKey: "", model: DEFAULT_MODELS.gemini, enabled: false },
    mistral: { type: "mistral", label: "Mistral", apiKey: "", model: DEFAULT_MODELS.mistral, enabled: false },
    grok: { type: "grok", label: "Grok", apiKey: "", model: DEFAULT_MODELS.grok, enabled: false },
    ollama: { type: "ollama", label: "Ollama", apiKey: "", model: DEFAULT_MODELS.ollama, baseUrl: "http://localhost:11434", enabled: false }
  },
  hotkeyFullscreen: "Alt+Shift+S",
  hotkeyRegion: "Alt+Shift+A",
  theme: "dark",
  accentColor: "#7c3aed",
  language: "auto",
  systemPrompt: DEFAULT_SYSTEM_PROMPT
};
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const DB_NAME = "screenai";
const DB_VERSION = 2;
const STORE_CONVERSATIONS = "conversations";
const STORE_PROJECTS = "projects";
class Database {
  db = null;
  async open() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db2 = req.result;
        if (!db2.objectStoreNames.contains(STORE_CONVERSATIONS)) {
          const s = db2.createObjectStore(STORE_CONVERSATIONS, { keyPath: "id" });
          s.createIndex("updatedAt", "updatedAt", { unique: false });
          s.createIndex("projectId", "projectId", { unique: false });
        }
        if (!db2.objectStoreNames.contains(STORE_PROJECTS)) {
          const s = db2.createObjectStore(STORE_PROJECTS, { keyPath: "id" });
          s.createIndex("updatedAt", "updatedAt", { unique: false });
        }
      };
      req.onsuccess = () => {
        this.db = req.result;
        resolve(this.db);
      };
      req.onerror = () => reject(req.error);
    });
  }
  async getAll(store) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readonly");
      const req = tx.objectStore(store).index("updatedAt").getAll();
      req.onsuccess = () => resolve(req.result.reverse());
      req.onerror = () => reject(req.error);
    });
  }
  async get(store, id) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(store, "readonly").objectStore(store).get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async put(store, item) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readwrite");
      tx.objectStore(store).put(item);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async del(store, id) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readwrite");
      tx.objectStore(store).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
const db = new Database();
const conversationStore = {
  getAll: () => db.getAll(STORE_CONVERSATIONS),
  async getStandalone() {
    return (await this.getAll()).filter((c) => !c.projectId);
  },
  async getByProject(projectId) {
    return (await this.getAll()).filter((c) => c.projectId === projectId);
  },
  get: (id) => db.get(STORE_CONVERSATIONS, id),
  async create(provider, model, projectId) {
    const c = {
      id: generateId(),
      title: "New conversation",
      messages: [],
      provider,
      model,
      projectId,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await db.put(STORE_CONVERSATIONS, c);
    return c;
  },
  async addMessage(id, msg) {
    const c = await this.get(id);
    if (!c) throw new Error(`Conversation ${id} not found`);
    c.messages.push(msg);
    c.updatedAt = Date.now();
    if (c.messages.filter((m) => m.role === "user").length === 1 && msg.role === "user" && msg.content) {
      c.title = msg.content.slice(0, 60) + (msg.content.length > 60 ? "…" : "");
    }
    await db.put(STORE_CONVERSATIONS, c);
    return c;
  },
  async update(id, updates) {
    const c = await this.get(id);
    if (!c) throw new Error(`Conversation ${id} not found`);
    const updated = { ...c, ...updates, updatedAt: Date.now() };
    await db.put(STORE_CONVERSATIONS, updated);
    return updated;
  },
  delete: (id) => db.del(STORE_CONVERSATIONS, id),
  async search(query) {
    const q = query.toLowerCase();
    return (await this.getAll()).filter(
      (c) => c.title.toLowerCase().includes(q) || c.messages.some((m) => m.content?.toLowerCase().includes(q))
    );
  }
};
const settingsStore = {
  key: "screenai_settings",
  async get() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        return new Promise((r) => chrome.storage.local.get(this.key, (res) => r(res[this.key] || { ...DEFAULT_SETTINGS })));
      }
    } catch {
    }
    const raw = localStorage.getItem(this.key);
    if (raw) try {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
    }
    return { ...DEFAULT_SETTINGS };
  },
  async save(s) {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        return new Promise((r) => chrome.storage.local.set({ [this.key]: s }, r));
      }
    } catch {
    }
    localStorage.setItem(this.key, JSON.stringify(s));
  }
};


true&&(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
}());

async function init() {
  const container = document.getElementById("conversations");
  const conversations = await conversationStore.getAll();
  if (conversations.length === 0) {
    container.innerHTML = '<div class="empty">No conversations yet. Take a capture to get started!</div>';
    return;
  }
  container.innerHTML = "";
  for (const convo of conversations.slice(0, 15)) {
    const date = new Date(convo.updatedAt).toLocaleDateString("fr-FR", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit"
    });
    const label = PROVIDER_LABELS[convo.provider] || convo.provider;
    const msgCount = convo.messages.length;
    const btn = document.createElement("button");
    btn.className = "convo-item";
    btn.innerHTML = `
      <div class="convo-title">${escapeHtml(convo.title)}</div>
      <div class="convo-meta">${label} · ${msgCount} messages · ${date}</div>
    `;
    btn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return;
      await chrome.storage.local.set({ screenai_resume_convo: convo.id });
      const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png", quality: 95 });
      chrome.tabs.sendMessage(tab.id, {
        type: "SCREENAI_CAPTURE",
        mode: "fullscreen",
        dataUrl,
        resumeConvoId: convo.id
      });
      window.close();
    });
    container.appendChild(btn);
  }
}
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
document.getElementById("highlight-btn")?.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: "toggle-highlight" });
    window.close();
  }
});
document.getElementById("settings-btn")?.addEventListener("click", () => {
  chrome.tabs.create({ url: "settings.html" });
});
document.getElementById("github-btn")?.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://github.com/Nono81/ScreenAI" });
});
init();
