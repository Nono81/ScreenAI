if (typeof globalThis.browser !== "undefined" && typeof globalThis.chrome === "undefined") {
  globalThis.chrome = globalThis.browser;
}
const DEFAULT_MODELS = {
  claude: "claude-sonnet-4-20250514",
  openai: "gpt-4o",
  gemini: "gemini-2.0-flash",
  mistral: "mistral-large-latest",
  grok: "grok-2-vision-1220",
  ollama: "llava"
};
const PROVIDER_LABELS = {
  claude: "Claude (Anthropic)",
  openai: "GPT (OpenAI)",
  gemini: "Gemini (Google)",
  mistral: "Mistral",
  grok: "Grok (xAI)",
  ollama: "Ollama (Local)"
};
const LANGUAGE_PROMPTS = {
  auto: "Respond in the user's language.",
  fr: "Réponds toujours en français.",
  en: "Always respond in English.",
  es: "Responde siempre en español.",
  de: "Antworte immer auf Deutsch."
};
const DEFAULT_SYSTEM_PROMPT = "You are a visual assistant. The user shares annotated screenshots to get help. Analyze the image and annotations (arrows, highlights, rectangles) to understand precisely what the user is showing you. Respond clearly and actionably.";
const DEFAULT_SETTINGS = {
  defaultProvider: "claude",
  providers: {
    claude: { type: "claude", label: "Claude", apiKey: "", model: DEFAULT_MODELS.claude, enabled: false },
    openai: { type: "openai", label: "OpenAI", apiKey: "", model: DEFAULT_MODELS.openai, enabled: false },
    gemini: { type: "gemini", label: "Gemini", apiKey: "", model: DEFAULT_MODELS.gemini, enabled: false },
    mistral: { type: "mistral", label: "Mistral", apiKey: "", model: DEFAULT_MODELS.mistral, enabled: false },
    grok: { type: "grok", label: "Grok", apiKey: "", model: DEFAULT_MODELS.grok, enabled: false },
    ollama: { type: "ollama", label: "Ollama", apiKey: "", model: DEFAULT_MODELS.ollama, baseUrl: "http://localhost:11434", enabled: false }
  },
  hotkeyFullscreen: "Alt+Shift+S",
  hotkeyRegion: "Alt+Shift+A",
  theme: "dark",
  accentColor: "#7c3aed",
  language: "auto",
  systemPrompt: DEFAULT_SYSTEM_PROMPT
};
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const DB_NAME = "screenai";
const DB_VERSION = 2;
const STORE_CONVERSATIONS = "conversations";
const STORE_PROJECTS = "projects";
class Database {
  db = null;
  async open() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db2 = req.result;
        if (!db2.objectStoreNames.contains(STORE_CONVERSATIONS)) {
          const s = db2.createObjectStore(STORE_CONVERSATIONS, { keyPath: "id" });
          s.createIndex("updatedAt", "updatedAt", { unique: false });
          s.createIndex("projectId", "projectId", { unique: false });
        }
        if (!db2.objectStoreNames.contains(STORE_PROJECTS)) {
          const s = db2.createObjectStore(STORE_PROJECTS, { keyPath: "id" });
          s.createIndex("updatedAt", "updatedAt", { unique: false });
        }
      };
      req.onsuccess = () => {
        this.db = req.result;
        resolve(this.db);
      };
      req.onerror = () => reject(req.error);
    });
  }
  async getAll(store) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readonly");
      const req = tx.objectStore(store).index("updatedAt").getAll();
      req.onsuccess = () => resolve(req.result.reverse());
      req.onerror = () => reject(req.error);
    });
  }
  async get(store, id) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(store, "readonly").objectStore(store).get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async put(store, item) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readwrite");
      tx.objectStore(store).put(item);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async del(store, id) {
    const db2 = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(store, "readwrite");
      tx.objectStore(store).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
const db = new Database();
const conversationStore = {
  getAll: () => db.getAll(STORE_CONVERSATIONS),
  async getStandalone() {
    return (await this.getAll()).filter((c) => !c.projectId);
  },
  async getByProject(projectId) {
    return (await this.getAll()).filter((c) => c.projectId === projectId);
  },
  get: (id) => db.get(STORE_CONVERSATIONS, id),
  async create(provider, model, projectId) {
    const c = {
      id: generateId(),
      title: "New conversation",
      messages: [],
      provider,
      model,
      projectId,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await db.put(STORE_CONVERSATIONS, c);
    return c;
  },
  async addMessage(id, msg) {
    const c = await this.get(id);
    if (!c) throw new Error(`Conversation ${id} not found`);
    c.messages.push(msg);
    c.updatedAt = Date.now();
    if (c.messages.filter((m) => m.role === "user").length === 1 && msg.role === "user" && msg.content) {
      c.title = msg.content.slice(0, 60) + (msg.content.length > 60 ? "…" : "");
    }
    await db.put(STORE_CONVERSATIONS, c);
    return c;
  },
  async update(id, updates) {
    const c = await this.get(id);
    if (!c) throw new Error(`Conversation ${id} not found`);
    const updated = { ...c, ...updates, updatedAt: Date.now() };
    await db.put(STORE_CONVERSATIONS, updated);
    return updated;
  },
  delete: (id) => db.del(STORE_CONVERSATIONS, id),
  async search(query) {
    const q = query.toLowerCase();
    return (await this.getAll()).filter(
      (c) => c.title.toLowerCase().includes(q) || c.messages.some((m) => m.content?.toLowerCase().includes(q))
    );
  }
};
const settingsStore = {
  key: "screenai_settings",
  async get() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        return new Promise((r) => chrome.storage.local.get(this.key, (res) => r(res[this.key] || { ...DEFAULT_SETTINGS })));
      }
    } catch {
    }
    const raw = localStorage.getItem(this.key);
    if (raw) try {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
    }
    return { ...DEFAULT_SETTINGS };
  },
  async save(s) {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        return new Promise((r) => chrome.storage.local.set({ [this.key]: s }, r));
      }
    } catch {
    }
    localStorage.setItem(this.key, JSON.stringify(s));
  }
};


class AnnotationCanvas {
  constructor(container, screenshotUrl, width, height) {
    this.container = container;
    this.screenshotUrl = screenshotUrl;
    this.width = width;
    this.height = height;
    this.canvas = document.createElement("canvas");
    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;cursor:crosshair;";
    this.ctx = this.canvas.getContext("2d");
    this.bgImage = new Image();
    this.bgImage.src = screenshotUrl;
    this.bgImage.onload = () => {
      this.redraw();
    };
    container.appendChild(this.canvas);
    this.bindEvents();
  }
  canvas;
  ctx;
  annotations = [];
  currentTool = "pointer";
  currentColor = "#FF3B30";
  lineWidth = 3;
  isDrawing = false;
  startX = 0;
  startY = 0;
  currentPoints = [];
  imageData = null;
  bgImage;
  scale = 1;
  setTool(tool) {
    this.currentTool = tool;
    this.canvas.style.cursor = tool === "pointer" ? "default" : tool === "text" ? "text" : "crosshair";
  }
  setColor(color) {
    this.currentColor = color;
  }
  setLineWidth(w) {
    this.lineWidth = w;
  }
  getAnnotations() {
    return [...this.annotations];
  }
  undo() {
    this.annotations.pop();
    this.redraw();
  }
  clear() {
    this.annotations = [];
    this.redraw();
  }
  // Get merged screenshot + annotations as dataUrl
  toDataUrl() {
    return this.canvas.toDataURL("image/png");
  }
  getCanvasCoords(e) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  }
  bindEvents() {
    this.canvas.addEventListener("mousedown", (e) => {
      if (this.currentTool === "pointer") return;
      const { x, y } = this.getCanvasCoords(e);
      this.isDrawing = true;
      this.startX = x;
      this.startY = y;
      this.currentPoints = [{ x, y }];
      this.imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
      if (this.currentTool === "text") {
        this.isDrawing = false;
        this.promptText(x, y);
      }
    });
    this.canvas.addEventListener("mousemove", (e) => {
      if (!this.isDrawing || this.currentTool === "pointer") return;
      const { x, y } = this.getCanvasCoords(e);
      this.currentPoints.push({ x, y });
      if (this.imageData) {
        this.ctx.putImageData(this.imageData, 0, 0);
      }
      this.drawShape(this.currentTool, this.currentPoints, this.currentColor, this.lineWidth, false);
    });
    this.canvas.addEventListener("mouseup", (e) => {
      if (!this.isDrawing || this.currentTool === "pointer") return;
      this.isDrawing = false;
      const { x, y } = this.getCanvasCoords(e);
      this.currentPoints.push({ x, y });
      this.annotations.push({
        type: this.currentTool,
        points: [...this.currentPoints],
        color: this.currentColor,
        lineWidth: this.lineWidth
      });
      this.redraw();
    });
  }
  promptText(x, y) {
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Texte...";
    input.style.cssText = `
      position: fixed;
      left: ${x / this.canvas.width * this.canvas.getBoundingClientRect().width + this.canvas.getBoundingClientRect().left}px;
      top: ${y / this.canvas.height * this.canvas.getBoundingClientRect().height + this.canvas.getBoundingClientRect().top}px;
      z-index: 2147483647;
      font-size: 16px;
      padding: 4px 8px;
      border: 2px solid ${this.currentColor};
      background: rgba(0,0,0,0.8);
      color: white;
      border-radius: 4px;
      outline: none;
      min-width: 120px;
    `;
    document.body.appendChild(input);
    input.focus();
    const commit = () => {
      if (input.value.trim()) {
        this.annotations.push({
          type: "text",
          points: [{ x, y }],
          color: this.currentColor,
          lineWidth: this.lineWidth,
          text: input.value.trim()
        });
        this.redraw();
      }
      input.remove();
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") commit();
      if (e.key === "Escape") input.remove();
    });
    input.addEventListener("blur", commit);
  }
  redraw() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    if (this.bgImage.complete) {
      this.ctx.drawImage(this.bgImage, 0, 0, this.canvas.width, this.canvas.height);
    }
    for (const ann of this.annotations) {
      this.drawShape(ann.type, ann.points, ann.color, ann.lineWidth, true, ann.text);
    }
  }
  drawShape(type, points, color, lineWidth, final, text) {
    const ctx = this.ctx;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    switch (type) {
      case "rectangle": {
        if (points.length < 2) break;
        const start = points[0];
        const end = points[points.length - 1];
        const w = end.x - start.x;
        const h = end.y - start.y;
        ctx.strokeRect(start.x, start.y, w, h);
        break;
      }
      case "highlight": {
        if (points.length < 2) break;
        const start = points[0];
        const end = points[points.length - 1];
        const w = end.x - start.x;
        const h = end.y - start.y;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(start.x, start.y, w, h);
        ctx.globalAlpha = 1;
        break;
      }
      case "arrow": {
        if (points.length < 2) break;
        const start = points[0];
        const end = points[points.length - 1];
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
        const angle = Math.atan2(end.y - start.y, end.x - start.x);
        const headLen = 15 + lineWidth * 2;
        ctx.beginPath();
        ctx.moveTo(end.x, end.y);
        ctx.lineTo(
          end.x - headLen * Math.cos(angle - Math.PI / 6),
          end.y - headLen * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          end.x - headLen * Math.cos(angle + Math.PI / 6),
          end.y - headLen * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();
        break;
      }
      case "freehand": {
        if (points.length < 2) break;
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);
        }
        ctx.stroke();
        break;
      }
      case "text": {
        if (!text || points.length < 1) break;
        const fontSize = 18 + lineWidth * 2;
        ctx.font = `bold ${fontSize}px -apple-system, BlinkMacSystemFont, sans-serif`;
        const metrics = ctx.measureText(text);
        const padding = 6;
        ctx.globalAlpha = 0.85;
        ctx.fillStyle = "#000";
        ctx.fillRect(
          points[0].x - padding,
          points[0].y - fontSize - padding,
          metrics.width + padding * 2,
          fontSize + padding * 2
        );
        ctx.globalAlpha = 1;
        ctx.fillStyle = color;
        ctx.fillText(text, points[0].x, points[0].y);
        break;
      }
    }
    ctx.restore();
  }
  destroy() {
    this.canvas.remove();
  }
}

class RegionSelector {
  constructor(container, screenshotUrl, onSelect, onCancel) {
    this.container = container;
    this.screenshotUrl = screenshotUrl;
    this.onSelect = onSelect;
    this.onCancel = onCancel;
    this.overlay = document.createElement("div");
    this.overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483640;
      background: url('${screenshotUrl}') no-repeat center/cover;
      cursor: crosshair;
    `;
    const dimmer = document.createElement("div");
    dimmer.style.cssText = `
      position: absolute; inset: 0;
      background: rgba(0,0,0,0.5);
      pointer-events: none;
    `;
    this.overlay.appendChild(dimmer);
    const hint = document.createElement("div");
    hint.textContent = "Select a region — Esc to cancel";
    hint.style.cssText = `
      position: absolute; top: 20px; left: 50%; transform: translateX(-50%);
      background: rgba(0,0,0,0.8); color: white; padding: 8px 20px;
      border-radius: 8px; font: 14px -apple-system, sans-serif;
      pointer-events: none; z-index: 10;
    `;
    this.overlay.appendChild(hint);
    this.selection = document.createElement("div");
    this.selection.style.cssText = `
      position: absolute; border: 2px solid #a78bfa;
      box-shadow: 0 0 0 9999px rgba(0,0,0,0.5);
      display: none; z-index: 5;
    `;
    this.overlay.appendChild(this.selection);
    container.appendChild(this.overlay);
    this.bindEvents();
  }
  overlay;
  isSelecting = false;
  startX = 0;
  startY = 0;
  selection;
  bindEvents() {
    this.overlay.addEventListener("mousedown", (e) => {
      this.isSelecting = true;
      this.startX = e.clientX;
      this.startY = e.clientY;
      this.selection.style.display = "block";
      this.updateSelection(e.clientX, e.clientY);
    });
    this.overlay.addEventListener("mousemove", (e) => {
      if (!this.isSelecting) return;
      this.updateSelection(e.clientX, e.clientY);
    });
    this.overlay.addEventListener("mouseup", (e) => {
      if (!this.isSelecting) return;
      this.isSelecting = false;
      const x = Math.min(this.startX, e.clientX);
      const y = Math.min(this.startY, e.clientY);
      const w = Math.abs(e.clientX - this.startX);
      const h = Math.abs(e.clientY - this.startY);
      if (w > 20 && h > 20) {
        this.destroy();
        this.onSelect({ x, y, w, h });
      }
    });
    document.addEventListener("keydown", this.handleKey);
  }
  handleKey = (e) => {
    if (e.key === "Escape") {
      this.destroy();
      this.onCancel();
    }
  };
  updateSelection(curX, curY) {
    const x = Math.min(this.startX, curX);
    const y = Math.min(this.startY, curY);
    const w = Math.abs(curX - this.startX);
    const h = Math.abs(curY - this.startY);
    this.selection.style.left = x + "px";
    this.selection.style.top = y + "px";
    this.selection.style.width = w + "px";
    this.selection.style.height = h + "px";
  }
  destroy() {
    document.removeEventListener("keydown", this.handleKey);
    this.overlay.remove();
  }
}
function cropScreenshot(dataUrl, region, viewportWidth, viewportHeight) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scaleX = img.width / viewportWidth;
      const scaleY = img.height / viewportHeight;
      const canvas = document.createElement("canvas");
      canvas.width = region.w * scaleX;
      canvas.height = region.h * scaleY;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(
        img,
        region.x * scaleX,
        region.y * scaleY,
        region.w * scaleX,
        region.h * scaleY,
        0,
        0,
        canvas.width,
        canvas.height
      );
      resolve(canvas.toDataURL("image/png"));
    };
    img.src = dataUrl;
  });
}

function extractBase64(dataUrl) {
  const match = dataUrl.match(/^data:(image\/\w+);base64,(.+)$/);
  if (!match) return { base64: dataUrl, mimeType: "image/png" };
  return { base64: match[2], mimeType: match[1] };
}
class ClaudeConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const apiMessages = messages.map((msg) => {
      const content = [];
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        const { base64, mimeType } = extractBase64(imgSrc);
        content.push({
          type: "image",
          source: { type: "base64", media_type: mimeType, data: base64 }
        });
      }
      content.push({ type: "text", text: msg.content || "Analyze this screenshot." });
      return { role: msg.role, content };
    });
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": this.config.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: this.config.model,
        max_tokens: 4096,
        stream: true,
        system: systemPrompt || "You are a visual assistant. The user shares annotated screenshots. Analyze the image and annotations to understand what the user is showing you. Respond in the user's language.",
        messages: apiMessages
      })
    });
    return this.handleSSE(response, onStream);
  }
  async handleSSE(response, onStream) {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") continue;
        try {
          const event = JSON.parse(data);
          if (event.type === "content_block_delta" && event.delta?.text) {
            full += event.delta.text;
            onStream(event.delta.text, false);
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
class OpenAIConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const sysContent = systemPrompt || "You are a visual assistant. Analyze annotated screenshots and respond in the user's language.";
    const apiMessages = [
      { role: "system", content: sysContent }
    ];
    for (const msg of messages) {
      const content = [];
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        content.push({ type: "image_url", image_url: { url: imgSrc, detail: "high" } });
      }
      content.push({ type: "text", text: msg.content || "Analyze this screenshot." });
      apiMessages.push({ role: msg.role, content });
    }
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model,
        max_tokens: 4096,
        stream: true,
        messages: apiMessages
      })
    });
    return this.handleSSE(response, onStream);
  }
  async handleSSE(response, onStream) {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") continue;
        try {
          const event = JSON.parse(data);
          const delta = event.choices?.[0]?.delta?.content;
          if (delta) {
            full += delta;
            onStream(delta, false);
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
class GeminiConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const sysContent = systemPrompt || "You are a visual assistant. Analyze annotated screenshots and respond in the user's language.";
    const contents = [];
    for (const msg of messages) {
      const parts = [];
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        const { base64, mimeType } = extractBase64(imgSrc);
        parts.push({ inline_data: { mime_type: mimeType, data: base64 } });
      }
      parts.push({ text: msg.content || "Analyze this screenshot." });
      contents.push({ role: msg.role === "assistant" ? "model" : "user", parts });
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.config.model}:streamGenerateContent?alt=sse&key=${this.config.apiKey}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: sysContent }] },
        contents
      })
    });
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        try {
          const event = JSON.parse(line.slice(6));
          const text = event.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) {
            full += text;
            onStream(text, false);
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
class MistralConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const sysContent = systemPrompt || "You are a visual assistant. Analyze annotated screenshots and respond in the user's language.";
    const apiMessages = [
      { role: "system", content: sysContent }
    ];
    for (const msg of messages) {
      const content = [];
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        content.push({ type: "image_url", image_url: { url: imgSrc } });
      }
      content.push({ type: "text", text: msg.content || "Analyze this screenshot." });
      apiMessages.push({ role: msg.role, content });
    }
    const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model,
        max_tokens: 4096,
        stream: true,
        messages: apiMessages
      })
    });
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") continue;
        try {
          const event = JSON.parse(data);
          const delta = event.choices?.[0]?.delta?.content;
          if (delta) {
            full += delta;
            onStream(delta, false);
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
class GrokConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const sysContent = systemPrompt || "You are a visual assistant. Analyze annotated screenshots and respond in the user's language.";
    const apiMessages = [
      { role: "system", content: sysContent }
    ];
    for (const msg of messages) {
      const content = [];
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        content.push({ type: "image_url", image_url: { url: imgSrc, detail: "high" } });
      }
      content.push({ type: "text", text: msg.content || "Analyze this screenshot." });
      apiMessages.push({ role: msg.role, content });
    }
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model,
        max_tokens: 4096,
        stream: true,
        messages: apiMessages
      })
    });
    return this.handleSSE(response, onStream);
  }
  async handleSSE(response, onStream) {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") continue;
        try {
          const event = JSON.parse(data);
          const delta = event.choices?.[0]?.delta?.content;
          if (delta) {
            full += delta;
            onStream(delta, false);
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
class OllamaConnector {
  constructor(config) {
    this.config = config;
  }
  async send(messages, systemPrompt, onStream) {
    const baseUrl = this.config.baseUrl || "http://localhost:11434";
    const sysContent = systemPrompt || "You are a visual assistant. Analyze annotated screenshots and respond in the user's language.";
    const ollamaMessages = messages.map((msg) => {
      const result = { role: msg.role, content: msg.content || "Analyze this screenshot." };
      if (msg.role === "user" && msg.screenshot) {
        const imgSrc = msg.screenshot.annotatedDataUrl || msg.screenshot.dataUrl;
        const { base64 } = extractBase64(imgSrc);
        result.images = [base64];
      }
      return result;
    });
    const response = await fetch(`${baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: this.config.model,
        messages: [
          { role: "system", content: sysContent },
          ...ollamaMessages
        ],
        stream: true
      })
    });
    const reader = response.body?.getReader();
    if (!reader) throw new Error("No response body");
    const decoder = new TextDecoder();
    let full = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const event = JSON.parse(line);
          if (event.message?.content) {
            full += event.message.content;
            onStream(event.message.content, false);
          }
          if (event.done) {
            onStream("", true);
            return full;
          }
        } catch {
        }
      }
    }
    onStream("", true);
    return full;
  }
}
function createConnector(config) {
  switch (config.type) {
    case "claude":
      return new ClaudeConnector(config);
    case "openai":
      return new OpenAIConnector(config);
    case "gemini":
      return new GeminiConnector(config);
    case "mistral":
      return new MistralConnector(config);
    case "grok":
      return new GrokConnector(config);
    case "ollama":
      return new OllamaConnector(config);
    default:
      throw new Error(`Unknown provider: ${config.type}`);
  }
}

function renderMarkdown(text) {
  let html = escapeHtml(text);
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
    return `<pre class="sai-code-block"><code class="language-${lang}">${code.trim()}</code></pre>`;
  });
  html = html.replace(/`([^`]+)`/g, '<code class="sai-inline-code">$1</code>');
  html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");
  html = html.replace(/^### (.+)$/gm, '<h4 class="sai-h4">$1</h4>');
  html = html.replace(/^## (.+)$/gm, '<h3 class="sai-h3">$1</h3>');
  html = html.replace(/^# (.+)$/gm, '<h2 class="sai-h2">$1</h2>');
  html = html.replace(/^- (.+)$/gm, "<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul class="sai-list">$&</ul>');
  html = html.replace(/^\d+\. (.+)$/gm, "<li>$1</li>");
  html = html.replace(/\n\n/g, "</p><p>");
  html = html.replace(/\n/g, "<br>");
  return `<p>${html}</p>`;
}
function escapeHtml(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;"
  };
  return text.replace(/[&<>]/g, (c) => map[c] || c);
}

class ScreenAIOverlay {
  constructor(screenshotUrl, mode) {
    this.screenshotUrl = screenshotUrl;
    this.mode = mode;
    this.root = document.createElement("div");
    this.root.id = "screenai-root";
    this.root.attachShadow({ mode: "open" });
    document.body.appendChild(this.root);
    this.init();
  }
  root;
  annotationCanvas = null;
  currentScreenshot = "";
  conversations = [];
  activeConvo = null;
  settings = null;
  isStreaming = false;
  currentView = "annotation";
  onClose = null;
  async init() {
    this.settings = await settingsStore.get();
    this.conversations = await conversationStore.getAll();
    if (this.mode === "region") {
      new RegionSelector(
        document.body,
        this.screenshotUrl,
        async (region) => {
          this.currentScreenshot = await cropScreenshot(
            this.screenshotUrl,
            region,
            window.innerWidth,
            window.innerHeight
          );
          this.buildUI();
        },
        () => this.destroy()
      );
    } else {
      this.currentScreenshot = this.screenshotUrl;
      this.buildUI();
    }
  }
  buildUI() {
    const shadow = this.root.shadowRoot;
    shadow.innerHTML = "";
    const style = document.createElement("style");
    style.textContent = this.getStyles();
    shadow.appendChild(style);
    const container = document.createElement("div");
    container.className = "sai-container";
    container.innerHTML = `
      <div class="sai-left">
        <div class="sai-toolbar" id="sai-toolbar"></div>
        <div class="sai-canvas-wrap" id="sai-canvas-wrap"></div>
      </div>
      <div class="sai-right" id="sai-right">
        <div class="sai-panel" id="sai-panel"></div>
      </div>
    `;
    shadow.appendChild(container);
    this.handleKeydown = (e) => {
      if (e.key === "Escape") this.destroy();
      if (e.ctrlKey && e.key === "z") this.annotationCanvas?.undo();
    };
    document.addEventListener("keydown", this.handleKeydown);
    this.buildToolbar(shadow.getElementById("sai-toolbar"));
    this.buildCanvas(shadow.getElementById("sai-canvas-wrap"));
    this.showConversationPicker();
  }
  handleKeydown = null;
  // ============================================
  // TOOLBAR (left side - annotation tools)
  // ============================================
  buildToolbar(container) {
    const tools = [
      { id: "pointer", icon: "🖱️", label: "Selection" },
      { id: "arrow", icon: "➡️", label: "Arrow" },
      { id: "rectangle", icon: "⬜", label: "Rectangle" },
      { id: "highlight", icon: "🟨", label: "Highlight" },
      { id: "freehand", icon: "✏️", label: "Freehand" },
      { id: "text", icon: "🔤", label: "Text" },
      { id: "undo", icon: "↩️", label: "Undo" },
      { id: "clear", icon: "🗑️", label: "Clear all" }
    ];
    const colors = ["#FF3B30", "#FF9500", "#FFCC00", "#34C759", "#007AFF", "#AF52DE", "#FFFFFF"];
    let html = '<div class="sai-tools">';
    for (const tool of tools) {
      html += `<button class="sai-tool-btn ${tool.id === "pointer" ? "active" : ""}" data-tool="${tool.id}" title="${tool.label}">${tool.icon}</button>`;
    }
    html += "</div>";
    html += '<div class="sai-colors">';
    for (const c of colors) {
      html += `<button class="sai-color-btn ${c === "#FF3B30" ? "active" : ""}" data-color="${c}" style="background:${c}" title="${c}"></button>`;
    }
    html += "</div>";
    html += `<div class="sai-toolbar-bottom">
      <button class="sai-btn sai-btn-close" id="sai-close-btn" title="Close (Esc)">✕</button>
    </div>`;
    container.innerHTML = html;
    container.querySelectorAll(".sai-tool-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tool = btn.dataset.tool;
        if (tool === "undo") {
          this.annotationCanvas?.undo();
          return;
        }
        if (tool === "clear") {
          this.annotationCanvas?.clear();
          return;
        }
        container.querySelectorAll(".sai-tool-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        this.annotationCanvas?.setTool(tool);
      });
    });
    container.querySelectorAll(".sai-color-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        container.querySelectorAll(".sai-color-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        this.annotationCanvas?.setColor(btn.dataset.color);
      });
    });
    container.querySelector("#sai-close-btn")?.addEventListener("click", () => this.destroy());
  }
  // ============================================
  // CANVAS (center - screenshot + annotations)
  // ============================================
  buildCanvas(container) {
    const img = new Image();
    img.src = this.currentScreenshot;
    img.onload = () => {
      this.annotationCanvas = new AnnotationCanvas(
        container,
        this.currentScreenshot,
        img.width,
        img.height
      );
    };
  }
  // ============================================
  // CONVERSATION PICKER (right panel)
  // ============================================
  showConversationPicker() {
    const panel = this.root.shadowRoot.getElementById("sai-panel");
    const provider = this.settings?.defaultProvider || "claude";
    let html = `
      <div class="sai-panel-header">
        <h2>💬 Conversation</h2>
        <button class="sai-icon-btn" id="sai-settings-btn" title="Settings">⚙️</button>
      </div>
      <div class="sai-panel-body">
        <button class="sai-btn sai-btn-primary sai-full-width" id="sai-new-convo">
          ＋ New conversation
        </button>
    `;
    if (this.conversations.length > 0) {
      html += '<div class="sai-divider"><span>or attach to</span></div>';
      html += '<div class="sai-convo-list">';
      for (const c of this.conversations.slice(0, 20)) {
        const date = new Date(c.updatedAt).toLocaleDateString("en-US", {
          day: "numeric",
          month: "short",
          hour: "2-digit",
          minute: "2-digit"
        });
        const msgCount = c.messages.length;
        html += `
          <button class="sai-convo-item" data-id="${c.id}">
            <div class="sai-convo-title">${this.escapeHtml(c.title)}</div>
            <div class="sai-convo-meta">${PROVIDER_LABELS[c.provider]} · ${msgCount} msg · ${date}</div>
          </button>
        `;
      }
      html += "</div>";
    }
    html += "</div>";
    panel.innerHTML = html;
    panel.querySelector("#sai-new-convo")?.addEventListener("click", async () => {
      const convo = await conversationStore.create(provider, this.settings.providers[provider].model);
      this.activeConvo = convo;
      this.showChat();
    });
    panel.querySelectorAll(".sai-convo-item").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        this.activeConvo = await conversationStore.get(id) || null;
        if (this.activeConvo) this.showChat();
      });
    });
    panel.querySelector("#sai-settings-btn")?.addEventListener("click", () => this.showSettings());
  }
  // ============================================
  // CHAT VIEW (right panel)
  // ============================================
  showChat() {
    const panel = this.root.shadowRoot.getElementById("sai-panel");
    if (!this.activeConvo) return;
    const provider = this.activeConvo.provider;
    const providerLabel = PROVIDER_LABELS[provider] || provider;
    let html = `
      <div class="sai-panel-header">
        <button class="sai-icon-btn" id="sai-back-btn" title="Back">←</button>
        <div class="sai-chat-title">
          <h3>${this.escapeHtml(this.activeConvo.title)}</h3>
          <span class="sai-provider-badge">${providerLabel}</span>
        </div>
        <button class="sai-icon-btn" id="sai-settings-btn2" title="Settings">⚙️</button>
      </div>
      <div class="sai-messages" id="sai-messages"></div>
      <div class="sai-input-area">
        <div class="sai-input-row">
          <textarea class="sai-input" id="sai-input" placeholder="Describe your problem or ask a question..." rows="2"></textarea>
          <button class="sai-btn sai-btn-send" id="sai-send-btn" title="Send">
            <span id="sai-send-icon">➤</span>
          </button>
        </div>
        <div class="sai-input-hint">
          The annotated capture will be sent with your message
        </div>
      </div>
    `;
    panel.innerHTML = html;
    this.renderMessages();
    panel.querySelector("#sai-back-btn")?.addEventListener("click", () => {
      this.showConversationPicker();
    });
    panel.querySelector("#sai-settings-btn2")?.addEventListener("click", () => this.showSettings());
    const input = panel.querySelector("#sai-input");
    const sendBtn = panel.querySelector("#sai-send-btn");
    const send = () => {
      if (this.isStreaming) return;
      const text = input.value.trim();
      if (!text && !this.currentScreenshot) return;
      input.value = "";
      this.sendMessage(text);
    };
    sendBtn.addEventListener("click", send);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    });
    input.focus();
  }
  renderMessages() {
    const container = this.root.shadowRoot.getElementById("sai-messages");
    if (!container || !this.activeConvo) return;
    let html = "";
    for (const msg of this.activeConvo.messages) {
      const isUser = msg.role === "user";
      html += `<div class="sai-msg ${isUser ? "sai-msg-user" : "sai-msg-ai"}">`;
      if (isUser && msg.screenshot?.annotatedDataUrl) {
        html += `<img class="sai-msg-screenshot" src="${msg.screenshot.annotatedDataUrl}" alt="capture">`;
      } else if (isUser && msg.screenshot?.dataUrl) {
        html += `<img class="sai-msg-screenshot" src="${msg.screenshot.dataUrl}" alt="capture">`;
      }
      if (msg.content) {
        html += `<div class="sai-msg-content">${isUser ? this.escapeHtml(msg.content) : renderMarkdown(msg.content)}</div>`;
      }
      html += "</div>";
    }
    container.innerHTML = html;
    container.scrollTop = container.scrollHeight;
  }
  // ============================================
  // SEND MESSAGE
  // ============================================
  async sendMessage(text) {
    if (!this.activeConvo || !this.settings) return;
    const provider = this.activeConvo.provider;
    const config = this.settings.providers[provider];
    if (!config.apiKey && provider !== "ollama") {
      this.showError("API key missing. Configure it in settings.");
      return;
    }
    const annotatedUrl = this.annotationCanvas?.toDataUrl() || this.currentScreenshot;
    const screenshot = {
      dataUrl: this.currentScreenshot,
      annotations: this.annotationCanvas?.getAnnotations() || [],
      annotatedDataUrl: annotatedUrl,
      timestamp: Date.now()
    };
    const userMsg = {
      id: generateId(),
      role: "user",
      content: text || "Help me with what you see on screen.",
      screenshot,
      timestamp: Date.now(),
      provider,
      model: config.model
    };
    this.activeConvo = await conversationStore.addMessage(this.activeConvo.id, userMsg);
    this.renderMessages();
    const aiMsg = {
      id: generateId(),
      role: "assistant",
      content: "",
      timestamp: Date.now(),
      provider,
      model: config.model
    };
    this.activeConvo.messages.push(aiMsg);
    this.renderMessages();
    this.isStreaming = true;
    this.updateSendButton(true);
    try {
      const connector = createConnector(config);
      const langPrompt = this.settings?.language && this.settings.language !== "auto" ? ` ${LANGUAGE_PROMPTS[this.settings.language]}` : " Respond in the user's language.";
      const fullPrompt = (this.settings?.systemPrompt || DEFAULT_SYSTEM_PROMPT) + langPrompt;
      await connector.send(this.activeConvo.messages.slice(0, -1), fullPrompt, (chunk, done) => {
        aiMsg.content += chunk;
        const messagesEl = this.root.shadowRoot.getElementById("sai-messages");
        if (messagesEl) {
          const lastMsg = messagesEl.querySelector(".sai-msg:last-child .sai-msg-content");
          if (lastMsg) {
            lastMsg.innerHTML = renderMarkdown(aiMsg.content);
          }
          messagesEl.scrollTop = messagesEl.scrollHeight;
        }
        if (done) {
          this.isStreaming = false;
          this.updateSendButton(false);
          conversationStore.addMessage(this.activeConvo.id, aiMsg).then((updated) => {
            this.activeConvo = updated;
          });
        }
      });
    } catch (err) {
      aiMsg.content = `❌ Error: ${err.message || "Could not reach the AI"}`;
      this.isStreaming = false;
      this.updateSendButton(false);
      this.renderMessages();
    }
  }
  updateSendButton(streaming) {
    const icon = this.root.shadowRoot.getElementById("sai-send-icon");
    if (icon) {
      icon.textContent = streaming ? "⏳" : "➤";
    }
  }
  showError(msg) {
    const messagesEl = this.root.shadowRoot.getElementById("sai-messages");
    if (messagesEl) {
      messagesEl.innerHTML += `<div class="sai-msg sai-msg-error"><div class="sai-msg-content">⚠️ ${msg}</div></div>`;
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }
  }
  // ============================================
  // SETTINGS VIEW
  // ============================================
  showSettings() {
    const panel = this.root.shadowRoot.getElementById("sai-panel");
    if (!this.settings) return;
    let html = `
      <div class="sai-panel-header">
        <button class="sai-icon-btn" id="sai-back-settings" title="Back">←</button>
        <h2>⚙️ Settings</h2>
      </div>
      <div class="sai-panel-body sai-settings-body">
        <div class="sai-setting-group">
          <label class="sai-label">Default AI</label>
          <select class="sai-select" id="sai-default-provider">
    `;
    for (const [key, label] of Object.entries(PROVIDER_LABELS)) {
      const selected = key === this.settings.defaultProvider ? "selected" : "";
      html += `<option value="${key}" ${selected}>${label}</option>`;
    }
    html += `</select></div>`;
    for (const [key, config] of Object.entries(this.settings.providers)) {
      const label = PROVIDER_LABELS[key];
      html += `
        <div class="sai-setting-group sai-provider-config">
          <div class="sai-provider-header">
            <h4>${label}</h4>
            <label class="sai-toggle">
              <input type="checkbox" data-provider="${key}" data-field="enabled" ${config.enabled ? "checked" : ""}>
              <span class="sai-toggle-slider"></span>
            </label>
          </div>
          <input class="sai-input-field" type="password" placeholder="API Key" 
            data-provider="${key}" data-field="apiKey" value="${config.apiKey}">
          <input class="sai-input-field" type="text" placeholder="Model" 
            data-provider="${key}" data-field="model" value="${config.model}">
          ${key === "ollama" ? `<input class="sai-input-field" type="text" placeholder="URL (http://localhost:11434)" 
            data-provider="${key}" data-field="baseUrl" value="${config.baseUrl || ""}">` : ""}
        </div>
      `;
    }
    html += `
      <button class="sai-btn sai-btn-primary sai-full-width" id="sai-save-settings">
        Save
      </button>
    </div>`;
    panel.innerHTML = html;
    panel.querySelector("#sai-back-settings")?.addEventListener("click", () => {
      if (this.activeConvo) this.showChat();
      else this.showConversationPicker();
    });
    panel.querySelector("#sai-save-settings")?.addEventListener("click", async () => {
      const select = panel.querySelector("#sai-default-provider");
      this.settings.defaultProvider = select.value;
      panel.querySelectorAll(".sai-input-field").forEach((input) => {
        const el = input;
        const provider = el.dataset.provider;
        const field = el.dataset.field;
        this.settings.providers[provider][field] = el.value;
      });
      panel.querySelectorAll('input[type="checkbox"]').forEach((input) => {
        const el = input;
        const provider = el.dataset.provider;
        this.settings.providers[provider].enabled = el.checked;
      });
      await settingsStore.save(this.settings);
      const btn = panel.querySelector("#sai-save-settings");
      btn.textContent = "✓ Saved";
      setTimeout(() => {
        btn.textContent = "Save";
      }, 1500);
    });
  }
  // ============================================
  // DESTROY
  // ============================================
  destroy() {
    if (this.handleKeydown) {
      document.removeEventListener("keydown", this.handleKeydown);
    }
    this.annotationCanvas?.destroy();
    this.root.remove();
    this.onClose?.();
  }
  // ============================================
  // UTILITIES
  // ============================================
  escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  // ============================================
  // STYLES
  // ============================================
  getStyles() {
    return `
      :host {
        all: initial;
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }

      * { box-sizing: border-box; margin: 0; padding: 0; }

      .sai-container {
        display: flex;
        width: 100vw;
        height: 100vh;
        background: #0d0d0d;
      }

      /* ---- LEFT: Canvas + Toolbar ---- */
      .sai-left {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-width: 0;
      }

      .sai-toolbar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        background: #1a1a2e;
        border-bottom: 1px solid #2a2a4a;
      }

      .sai-tools {
        display: flex;
        gap: 4px;
      }

      .sai-tool-btn {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        border: 1px solid transparent;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.15s;
      }

      .sai-tool-btn:hover {
        background: rgba(255,255,255,0.1);
        border-color: rgba(255,255,255,0.15);
      }

      .sai-tool-btn.active {
        background: #a78bfa;
        border-color: #a78bfa;
        box-shadow: 0 0 12px rgba(79,195,247,0.4);
      }

      .sai-colors {
        display: flex;
        gap: 4px;
        margin-left: 12px;
        padding-left: 12px;
        border-left: 1px solid #2a2a4a;
      }

      .sai-color-btn {
        width: 22px;
        height: 22px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        transition: all 0.15s;
      }

      .sai-color-btn:hover {
        transform: scale(1.2);
      }

      .sai-color-btn.active {
        border-color: white;
        box-shadow: 0 0 8px rgba(255,255,255,0.4);
      }

      .sai-toolbar-bottom {
        margin-left: auto;
      }

      .sai-canvas-wrap {
        flex: 1;
        position: relative;
        overflow: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #111;
      }

      .sai-canvas-wrap canvas {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
      }

      /* ---- RIGHT: Panel ---- */
      .sai-right {
        width: 400px;
        min-width: 400px;
        display: flex;
        flex-direction: column;
        background: #13132b;
        border-left: 1px solid #2a2a4a;
      }

      .sai-panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
      }

      .sai-panel-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        background: #1a1a2e;
        border-bottom: 1px solid #2a2a4a;
      }

      .sai-panel-header h2, .sai-panel-header h3 {
        color: #e0e0e0;
        font-size: 15px;
        font-weight: 600;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .sai-chat-title {
        flex: 1;
        min-width: 0;
      }

      .sai-chat-title h3 {
        font-size: 13px;
      }

      .sai-provider-badge {
        font-size: 10px;
        color: #a78bfa;
        background: rgba(79,195,247,0.1);
        padding: 2px 8px;
        border-radius: 10px;
        display: inline-block;
        margin-top: 2px;
      }

      .sai-panel-body {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
      }

      /* ---- Buttons ---- */
      .sai-btn {
        padding: 8px 16px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.15s;
      }

      .sai-btn-primary {
        background: #a78bfa;
        color: #0d0d0d;
        font-weight: 600;
      }

      .sai-btn-primary:hover {
        background: #81D4FA;
        box-shadow: 0 4px 15px rgba(79,195,247,0.3);
      }

      .sai-btn-close {
        background: rgba(255,60,60,0.2);
        color: #ff6b6b;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        font-size: 16px;
        padding: 0;
      }

      .sai-btn-close:hover {
        background: rgba(255,60,60,0.4);
      }

      .sai-icon-btn {
        background: transparent;
        border: none;
        cursor: pointer;
        font-size: 18px;
        padding: 4px;
        border-radius: 6px;
        transition: background 0.15s;
      }

      .sai-icon-btn:hover {
        background: rgba(255,255,255,0.1);
      }

      .sai-full-width { width: 100%; }

      /* ---- Conversation List ---- */
      .sai-divider {
        display: flex;
        align-items: center;
        margin: 16px 0;
        color: #666;
        font-size: 12px;
      }

      .sai-divider::before, .sai-divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: #2a2a4a;
      }

      .sai-divider span {
        padding: 0 10px;
      }

      .sai-convo-list {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .sai-convo-item {
        display: block;
        width: 100%;
        text-align: left;
        padding: 10px 12px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 10px;
        cursor: pointer;
        transition: all 0.15s;
      }

      .sai-convo-item:hover {
        background: rgba(79,195,247,0.1);
        border-color: rgba(79,195,247,0.2);
      }

      .sai-convo-title {
        color: #e0e0e0;
        font-size: 13px;
        font-weight: 500;
        margin-bottom: 4px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .sai-convo-meta {
        color: #666;
        font-size: 11px;
      }

      /* ---- Chat Messages ---- */
      .sai-messages {
        flex: 1;
        overflow-y: auto;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .sai-msg {
        max-width: 95%;
        border-radius: 12px;
        padding: 10px 14px;
        font-size: 13px;
        line-height: 1.5;
        word-wrap: break-word;
      }

      .sai-msg-user {
        align-self: flex-end;
        background: #1e3a5f;
        color: #e0e0e0;
        border-bottom-right-radius: 4px;
      }

      .sai-msg-ai {
        align-self: flex-start;
        background: #1e1e3a;
        color: #d0d0d0;
        border-bottom-left-radius: 4px;
      }

      .sai-msg-error {
        align-self: center;
        background: rgba(255,60,60,0.15);
        color: #ff6b6b;
      }

      .sai-msg-screenshot {
        display: block;
        max-width: 100%;
        max-height: 150px;
        border-radius: 8px;
        margin-bottom: 8px;
        border: 1px solid rgba(255,255,255,0.1);
      }

      .sai-msg-content {
        color: inherit;
      }

      .sai-msg-content p { margin-bottom: 8px; }
      .sai-msg-content p:last-child { margin-bottom: 0; }

      .sai-msg-content .sai-code-block {
        background: #0d0d1a;
        border-radius: 8px;
        padding: 10px 12px;
        overflow-x: auto;
        font-family: 'SF Mono', Monaco, Consolas, monospace;
        font-size: 12px;
        margin: 8px 0;
        border: 1px solid #2a2a4a;
      }

      .sai-msg-content .sai-inline-code {
        background: rgba(79,195,247,0.15);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: 'SF Mono', Monaco, Consolas, monospace;
        font-size: 12px;
      }

      .sai-msg-content .sai-list {
        padding-left: 18px;
        margin: 6px 0;
      }

      .sai-msg-content strong { color: #a78bfa; }

      /* ---- Input Area ---- */
      .sai-input-area {
        padding: 12px;
        border-top: 1px solid #2a2a4a;
        background: #1a1a2e;
      }

      .sai-input-row {
        display: flex;
        gap: 8px;
      }

      .sai-input {
        flex: 1;
        padding: 10px 14px;
        background: #0d0d1a;
        border: 1px solid #2a2a4a;
        border-radius: 10px;
        color: #e0e0e0;
        font-size: 13px;
        font-family: inherit;
        resize: none;
        outline: none;
        transition: border-color 0.15s;
      }

      .sai-input:focus {
        border-color: #a78bfa;
      }

      .sai-input::placeholder {
        color: #555;
      }

      .sai-btn-send {
        width: 44px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #a78bfa;
        color: #0d0d0d;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        font-size: 18px;
        transition: all 0.15s;
        padding: 0;
      }

      .sai-btn-send:hover {
        background: #81D4FA;
        box-shadow: 0 4px 15px rgba(79,195,247,0.3);
      }

      .sai-input-hint {
        font-size: 11px;
        color: #555;
        margin-top: 6px;
        padding-left: 4px;
      }

      /* ---- Settings ---- */
      .sai-settings-body {
        display: flex;
        flex-direction: column;
        gap: 16px;
      }

      .sai-setting-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .sai-label {
        font-size: 12px;
        color: #888;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .sai-select, .sai-input-field {
        padding: 8px 12px;
        background: #0d0d1a;
        border: 1px solid #2a2a4a;
        border-radius: 8px;
        color: #e0e0e0;
        font-size: 13px;
        outline: none;
        transition: border-color 0.15s;
      }

      .sai-select:focus, .sai-input-field:focus {
        border-color: #a78bfa;
      }

      .sai-provider-config {
        background: rgba(255,255,255,0.02);
        padding: 12px;
        border-radius: 10px;
        border: 1px solid rgba(255,255,255,0.05);
      }

      .sai-provider-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
      }

      .sai-provider-header h4 {
        color: #ccc;
        font-size: 13px;
      }

      /* Toggle switch */
      .sai-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
      }

      .sai-toggle input { opacity: 0; width: 0; height: 0; }

      .sai-toggle-slider {
        position: absolute;
        inset: 0;
        background: #333;
        border-radius: 22px;
        cursor: pointer;
        transition: 0.2s;
      }

      .sai-toggle-slider::before {
        content: '';
        position: absolute;
        width: 16px;
        height: 16px;
        left: 3px;
        bottom: 3px;
        background: white;
        border-radius: 50%;
        transition: 0.2s;
      }

      .sai-toggle input:checked + .sai-toggle-slider {
        background: #a78bfa;
      }

      .sai-toggle input:checked + .sai-toggle-slider::before {
        transform: translateX(18px);
      }

      /* Scrollbar */
      ::-webkit-scrollbar { width: 6px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb { background: #333; border-radius: 3px; }
      ::-webkit-scrollbar-thumb:hover { background: #555; }
    `;
  }
}

const highlightCSS = "/* ============================================\n   ScreenAI — Highlight Styles (v1.1)\n   ============================================ */\n\n/* === Surlignage === */\nmark.screenai-highlight {\n  background: rgba(167, 139, 250, 0.35); /* violet-400 semi-transparent */\n  border-radius: 2px;\n  padding: 1px 0;\n  box-decoration-break: clone;\n  -webkit-box-decoration-break: clone;\n}\n\n/* === Mode actif === */\nbody.screenai-highlight-mode {\n  cursor: text !important;\n}\n\nbody.screenai-highlight-mode * {\n  cursor: text !important;\n}\n\n/* === Badge flottant === */\n#screenai-highlight-badge {\n  position: fixed;\n  bottom: 20px;\n  right: 20px;\n  z-index: 999999;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 14px;\n  background: #2e1065; /* violet-950 */\n  color: white;\n  border-radius: 10px;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;\n  font-size: 13px;\n  box-shadow: 0 4px 20px rgba(124, 58, 237, 0.3);\n  animation: screenai-badge-in 0.2s ease-out;\n  user-select: none;\n}\n\n#screenai-highlight-badge .screenai-badge-icon {\n  font-size: 16px;\n}\n\n#screenai-highlight-badge button {\n  background: rgba(255, 255, 255, 0.15);\n  border: none;\n  color: white;\n  padding: 3px 10px;\n  border-radius: 6px;\n  cursor: pointer;\n  font-size: 12px;\n  font-family: inherit;\n  transition: background 0.15s;\n}\n\n#screenai-highlight-badge button:hover {\n  background: rgba(255, 255, 255, 0.25);\n}\n\n#screenai-highlight-close {\n  font-size: 16px;\n  padding: 2px 6px;\n}\n\n@keyframes screenai-badge-in {\n  from { opacity: 0; transform: translateY(10px); }\n  to { opacity: 1; transform: translateY(0); }\n}\n";

const styleEl = document.createElement("style");
styleEl.textContent = highlightCSS;
document.head.appendChild(styleEl);
class HighlightManager {
  static instance = null;
  active = false;
  highlightCount = 0;
  badge = null;
  boundMouseUp = null;
  boundKeyDown = null;
  static getInstance() {
    if (!HighlightManager.instance) {
      HighlightManager.instance = new HighlightManager();
    }
    return HighlightManager.instance;
  }
  isActive() {
    return this.active;
  }
  toggle() {
    this.active ? this.deactivate() : this.activate();
  }
  activate() {
    if (this.active) return;
    this.active = true;
    document.body.style.cursor = "text";
    document.body.classList.add("screenai-highlight-mode");
    this.boundMouseUp = this.handleMouseUp.bind(this);
    this.boundKeyDown = this.handleKeyDown.bind(this);
    document.addEventListener("mouseup", this.boundMouseUp);
    document.addEventListener("keydown", this.boundKeyDown);
    this.createBadge();
  }
  deactivate() {
    if (!this.active) return;
    this.active = false;
    document.body.style.cursor = "";
    document.body.classList.remove("screenai-highlight-mode");
    if (this.boundMouseUp) {
      document.removeEventListener("mouseup", this.boundMouseUp);
    }
    if (this.boundKeyDown) {
      document.removeEventListener("keydown", this.boundKeyDown);
    }
    if (this.badge && this.badge.parentNode) {
      this.badge.parentNode.removeChild(this.badge);
      this.badge = null;
    }
  }
  handleKeyDown(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      this.deactivate();
    }
  }
  handleMouseUp(_e) {
    if (!this.active) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const text = range.toString().trim();
    if (!text) return;
    const container = range.startContainer.parentElement;
    if (container && (container.isContentEditable || container.tagName === "INPUT" || container.tagName === "TEXTAREA" || container.closest('input, textarea, [contenteditable="true"]'))) {
      selection.removeAllRanges();
      return;
    }
    try {
      this.wrapRange(range);
      this.highlightCount++;
      this.updateBadge();
    } catch (err) {
      console.warn("[ScreenAI] Highlight wrap failed:", err);
    }
    selection.removeAllRanges();
  }
  wrapRange(range) {
    if (range.startContainer === range.endContainer && range.startContainer.nodeType === Node.TEXT_NODE) {
      const mark = document.createElement("mark");
      mark.className = "screenai-highlight";
      range.surroundContents(mark);
      return;
    }
    const textNodes = [];
    const walker = document.createTreeWalker(
      range.commonAncestorContainer,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const nodeRange = document.createRange();
          nodeRange.selectNodeContents(node);
          if (range.compareBoundaryPoints(Range.START_TO_END, nodeRange) > 0 && range.compareBoundaryPoints(Range.END_TO_START, nodeRange) < 0) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );
    while (walker.nextNode()) {
      textNodes.push(walker.currentNode);
    }
    for (const textNode of textNodes) {
      const mark = document.createElement("mark");
      mark.className = "screenai-highlight";
      const parent = textNode.parentNode;
      if (parent) {
        parent.insertBefore(mark, textNode);
        mark.appendChild(textNode);
      }
    }
  }
  clearAll() {
    const highlights = document.querySelectorAll("mark.screenai-highlight");
    highlights.forEach((mark) => {
      const parent = mark.parentNode;
      if (parent) {
        while (mark.firstChild) {
          parent.insertBefore(mark.firstChild, mark);
        }
        parent.removeChild(mark);
        parent.normalize();
      }
    });
    this.highlightCount = 0;
    this.updateBadge();
  }
  createBadge() {
    if (this.badge) return;
    this.badge = document.createElement("div");
    this.badge.id = "screenai-highlight-badge";
    this.badge.innerHTML = `
      <span class="screenai-badge-icon">&#9998;</span>
      <span class="screenai-badge-text">
        Mode surlignage actif &mdash;
        <span id="screenai-highlight-count">0</span> passage(s)
      </span>
      <button id="screenai-highlight-clear" title="Effacer tout">
        Effacer
      </button>
      <button id="screenai-highlight-close" title="Quitter (Echap)">
        &times;
      </button>
    `;
    document.body.appendChild(this.badge);
    document.getElementById("screenai-highlight-clear")?.addEventListener("click", () => this.clearAll());
    document.getElementById("screenai-highlight-close")?.addEventListener("click", () => this.deactivate());
  }
  updateBadge() {
    const counter = document.getElementById("screenai-highlight-count");
    if (counter) {
      counter.textContent = String(this.highlightCount);
    }
  }
  destroy() {
    this.deactivate();
    this.clearAll();
    HighlightManager.instance = null;
  }
}
const manager = HighlightManager.getInstance();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "toggle-highlight") {
    manager.toggle();
    sendResponse({ active: manager.isActive() });
  }
  if (message.action === "clear-highlights") {
    manager.clearAll();
    sendResponse({ cleared: true });
  }
});

let overlay = null;
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SCREENAI_CAPTURE") {
    if (overlay) {
      overlay.destroy();
    }
    overlay = new ScreenAIOverlay(msg.dataUrl, msg.mode);
    overlay.onClose = () => {
      overlay = null;
    };
  }
});
document.addEventListener("keydown", (e) => {
  if (e.altKey && e.shiftKey && e.key === "S") {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: "SCREENAI_CAPTURE_TAB" }, (response) => {
      if (response?.dataUrl) {
        if (overlay) overlay.destroy();
        overlay = new ScreenAIOverlay(response.dataUrl, "fullscreen");
        overlay.onClose = () => {
          overlay = null;
        };
      }
    });
  }
  if (e.altKey && e.shiftKey && e.key === "A") {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: "SCREENAI_CAPTURE_TAB" }, (response) => {
      if (response?.dataUrl) {
        if (overlay) overlay.destroy();
        overlay = new ScreenAIOverlay(response.dataUrl, "region");
        overlay.onClose = () => {
          overlay = null;
        };
      }
    });
  }
});
